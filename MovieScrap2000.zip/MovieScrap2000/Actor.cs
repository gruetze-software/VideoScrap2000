﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MovieScrap2000
{
	public class Actor
	{
		[XmlElement("name")]
		public string Name { get; set; } = "";

		[XmlElement("role")]
		public string Role { get; set; } = "";

		[XmlElement("order")]
		public int Order { get; set; }

		[XmlElement("thumb")]
		public string? Thumb { get; set; }

		// Neu hinzugefügt
		[XmlElement("tmdbid")]
		public string TmdbId { get; set; } = "";
	}
}
