﻿using Microsoft.Data.Sqlite;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace MovieScrap2000
{
  public class DatabaseManager
  {
    private readonly string _databasePath;
    private readonly string _connectionString;
    private const int SchemaVersion = 1; // Für zukünftige Datenbank-Upgrades

    // Konstruktor: Definiert den Pfad und den Connection String
    public DatabaseManager(string dbFileName = "MovieScrap2000_Cache.sqlite")
    {
      // Speichere die Datenbankdatei im Anwendungsordner
      _databasePath = Path.Combine(Utils.GetOptionsPath(), dbFileName);

      // Connection String für SQLite
      _connectionString = $"Data Source={_databasePath}";
    }

    // Öffentliche Methode zum Initialisieren der Datenbank
    public async Task InitializeDatabaseAsync()
    {
			// Wir erstellen die Verbindung und prüfen das Schema innerhalb einer Transaktion
			using (var connection = GetConnection())
			{
				// Die Methode GetCreationSQL() enthält die PRAGMA foreign_keys = ON; Anweisung,
				// die zu Beginn der Verbindung ausgeführt werden sollte.
				string creationSql = GetCreationSQL();
				using (var command = connection.CreateCommand())
				{
					command.CommandText = creationSql;
					await command.ExecuteNonQueryAsync();
				}
			}
		}

    // Liefert eine geöffnete Verbindung zurück
    public SqliteConnection GetConnection()
    {
      var connection = new SqliteConnection(_connectionString);
      connection.Open();
      return connection;
    }

		/// <summary>
		/// Liefert den vollständigen SQL-String zur Erstellung aller Tabellen.
		/// </summary>
		private string GetCreationSQL()
		{
      return  @"PRAGMA foreign_keys = ON;

-- I. Stammdaten-Tabellen (Lookup Tables)
CREATE TABLE IF NOT EXISTS Actor (
    Id INTEGER PRIMARY KEY,
    Name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Director (
    Id INTEGER PRIMARY KEY,
    Name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Studio (
    Id INTEGER PRIMARY KEY,
    Name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Genre (
    Id INTEGER PRIMARY KEY,
    Name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Country (
    Id INTEGER PRIMARY KEY,
    Name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Credit (
    Id INTEGER PRIMARY KEY,
    Name TEXT NOT NULL UNIQUE
);

-- II. Haupttabellen (Inhaltstypen)
CREATE TABLE IF NOT EXISTS Movie (
    Id INTEGER PRIMARY KEY,
    ImdbId TEXT UNIQUE,
    TMDbId INTEGER,
    Title TEXT NOT NULL,
    OriginalTitle TEXT,
    CollectionId INTEGER,
    CollectionName TEXT,
    Year TEXT,
    ReleaseDate TEXT,
    Mpaa TEXT,
    Plot TEXT,
    Outline TEXT,
    Tagline TEXT,
    Runtime INTEGER,
    Rating REAL,
    Votes INTEGER,
    FolderPath TEXT NOT NULL UNIQUE,
    VideoFilePath TEXT,
    ScrapStatus INTEGER NOT NULL DEFAULT 1,
    NfoModified INTEGER,
    DateAdded TEXT NOT NULL,
    DateModified TEXT NOT NULL,
    JsonMetadata TEXT
);

CREATE TABLE IF NOT EXISTS TvShow (
    Id INTEGER PRIMARY KEY,
    Title TEXT NOT NULL,
    Premiered TEXT,
    Status TEXT,
    Plot TEXT,
    FolderPath TEXT NOT NULL UNIQUE,
    NfoLastModified INTEGER,
    DateAdded TEXT NOT NULL,
    DateModified TEXT NOT NULL,
    TMDbId INTEGER,
    JsonMetadata TEXT
);

CREATE TABLE IF NOT EXISTS Episode (
    Id INTEGER PRIMARY KEY,
    TvShowId INTEGER NOT NULL,
    SeasonNumber INTEGER NOT NULL,
    EpisodeNumber INTEGER NOT NULL,
    Title TEXT NOT NULL,
    Aired TEXT,
    Plot TEXT,
    NfoPath TEXT NOT NULL UNIQUE,
    JsonMetadata TEXT,
    NfoLastModified INTEGER,
    DateAdded TEXT NOT NULL,
    DateModified TEXT NOT NULL,
    FOREIGN KEY (TvShowId) REFERENCES TvShow(Id) ON DELETE CASCADE
);

-- III. Verbindungstabellen (N:M Junction Tables)
CREATE TABLE IF NOT EXISTS MovieActor (
    MovieId INTEGER NOT NULL,
    ActorId INTEGER NOT NULL,
    Role TEXT,
    SortOrder INTEGER,
    PRIMARY KEY (MovieId, ActorId),
    FOREIGN KEY (MovieId) REFERENCES Movie(Id) ON DELETE CASCADE,
    FOREIGN KEY (ActorId) REFERENCES Actor(Id)
);

CREATE TABLE IF NOT EXISTS MovieDirector (
    MovieId INTEGER NOT NULL,
    DirectorId INTEGER NOT NULL,
    PRIMARY KEY (MovieId, DirectorId),
    FOREIGN KEY (MovieId) REFERENCES Movie(Id) ON DELETE CASCADE,
    FOREIGN KEY (DirectorId) REFERENCES Director(Id)
);

CREATE TABLE IF NOT EXISTS MovieStudio (
    MovieId INTEGER NOT NULL,
    StudioId INTEGER NOT NULL,
    PRIMARY KEY (MovieId, StudioId),
    FOREIGN KEY (MovieId) REFERENCES Movie(Id) ON DELETE CASCADE,
    FOREIGN KEY (StudioId) REFERENCES Studio(Id)
);

CREATE TABLE IF NOT EXISTS MovieGenre (
    MovieId INTEGER NOT NULL,
    GenreId INTEGER NOT NULL,
    PRIMARY KEY (MovieId, GenreId),
    FOREIGN KEY (MovieId) REFERENCES Movie(Id) ON DELETE CASCADE,
    FOREIGN KEY (GenreId) REFERENCES Genre(Id)
);

CREATE TABLE IF NOT EXISTS MovieCountry (
    MovieId INTEGER NOT NULL,
    CountryId INTEGER NOT NULL,
    PRIMARY KEY (MovieId, CountryId),
    FOREIGN KEY (MovieId) REFERENCES Movie(Id) ON DELETE CASCADE,
    FOREIGN KEY (CountryId) REFERENCES Country(Id)
);

CREATE TABLE IF NOT EXISTS MovieCredit (
    MovieId INTEGER NOT NULL,
    CreditId INTEGER NOT NULL,
    PRIMARY KEY (MovieId, CreditId),
    FOREIGN KEY (MovieId) REFERENCES Movie(Id) ON DELETE CASCADE,
    FOREIGN KEY (CreditId) REFERENCES Credit(Id)
);

-- V. Caching-Tabelle
CREATE TABLE IF NOT EXISTS ImageCache (
    Id INTEGER PRIMARY KEY,
    MovieId INTEGER,
    TvShowId INTEGER,
    EpisodeId INTEGER,
    Type TEXT NOT NULL,
    Data BLOB NOT NULL,
    FOREIGN KEY (MovieId) REFERENCES Movie(Id) ON DELETE CASCADE,
    FOREIGN KEY (TvShowId) REFERENCES TvShow(Id) ON DELETE CASCADE,
    FOREIGN KEY (EpisodeId) REFERENCES Episode(Id) ON DELETE CASCADE,
    CHECK (
        (MovieId IS NULL) +
        (TvShowId IS NULL) +
        (EpisodeId IS NULL) = 2
    )
);";  
    }
	}
}