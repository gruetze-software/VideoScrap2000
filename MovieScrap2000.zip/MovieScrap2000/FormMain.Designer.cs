﻿namespace MovieScrap2000
{
    partial class FormMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
			splitContainerMain = new SplitContainer();
			fluentListViewMovies = new Fluent.Lists.AdvancedListView();
			toolStrip1 = new ToolStrip();
			toolStripButton4 = new ToolStripButton();
			splitContainerMovie = new SplitContainer();
			tableLayoutPanelMovieTitle = new TableLayoutPanel();
			tableLayoutPanelMovie = new TableLayoutPanel();
			tableLayoutPanelDetails = new TableLayoutPanel();
			label1 = new Label();
			label2 = new Label();
			label4 = new Label();
			textBoxMovieTitle = new TextBox();
			textBoxMovieYear = new TextBox();
			textBoxMovieTitleOri = new TextBox();
			label3 = new Label();
			textBoxMovieDirector = new TextBox();
			label5 = new Label();
			dateTimePickerMovieRelease = new DateTimePicker();
			label6 = new Label();
			textBoxMovieRating = new TextBox();
			tableLayoutPanelInhalt = new TableLayoutPanel();
			groupBox1 = new GroupBox();
			textBoxMoviePlot = new TextBox();
			groupBox2 = new GroupBox();
			textBoxMovieInhalt = new TextBox();
			flowLayoutPanelMoviePictures = new FlowLayoutPanel();
			statusStripMain = new StatusStrip();
			toolStripProgressBarMain = new ToolStripProgressBar();
			toolStripStatusLabelMain = new ToolStripStatusLabel();
			toolStripMain = new ToolStrip();
			toolStripButton1 = new ToolStripButton();
			toolStripButton2 = new ToolStripButton();
			toolStripButton3 = new ToolStripButton();
			((System.ComponentModel.ISupportInitialize)splitContainerMain).BeginInit();
			splitContainerMain.Panel1.SuspendLayout();
			splitContainerMain.Panel2.SuspendLayout();
			splitContainerMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)fluentListViewMovies).BeginInit();
			toolStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)splitContainerMovie).BeginInit();
			splitContainerMovie.Panel1.SuspendLayout();
			splitContainerMovie.Panel2.SuspendLayout();
			splitContainerMovie.SuspendLayout();
			tableLayoutPanelMovie.SuspendLayout();
			tableLayoutPanelDetails.SuspendLayout();
			tableLayoutPanelInhalt.SuspendLayout();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			statusStripMain.SuspendLayout();
			toolStripMain.SuspendLayout();
			SuspendLayout();
			// 
			// splitContainerMain
			// 
			splitContainerMain.Dock = DockStyle.Fill;
			splitContainerMain.Location = new Point(0, 39);
			splitContainerMain.Margin = new Padding(3, 4, 3, 4);
			splitContainerMain.Name = "splitContainerMain";
			// 
			// splitContainerMain.Panel1
			// 
			splitContainerMain.Panel1.Controls.Add(fluentListViewMovies);
			splitContainerMain.Panel1.Controls.Add(toolStrip1);
			// 
			// splitContainerMain.Panel2
			// 
			splitContainerMain.Panel2.Controls.Add(splitContainerMovie);
			splitContainerMain.Size = new Size(1125, 815);
			splitContainerMain.SplitterDistance = 497;
			splitContainerMain.SplitterWidth = 5;
			splitContainerMain.TabIndex = 0;
			// 
			// fluentListViewMovies
			// 
			fluentListViewMovies.CellEditUseWholeCell = false;
			fluentListViewMovies.Dock = DockStyle.Fill;
			fluentListViewMovies.FullRowSelect = true;
			fluentListViewMovies.GridLines = true;
			fluentListViewMovies.Location = new Point(0, 27);
			fluentListViewMovies.Margin = new Padding(3, 4, 3, 4);
			fluentListViewMovies.Name = "fluentListViewMovies";
			fluentListViewMovies.ShowGroups = false;
			fluentListViewMovies.ShowImagesOnSubItems = true;
			fluentListViewMovies.ShowItemCountOnGroups = true;
			fluentListViewMovies.Size = new Size(497, 788);
			fluentListViewMovies.TabIndex = 1;
			fluentListViewMovies.View = View.Details;
			fluentListViewMovies.SelectionChanged += fluentListViewMovies_SelectionChanged;
			// 
			// toolStrip1
			// 
			toolStrip1.ImageScalingSize = new Size(20, 20);
			toolStrip1.Items.AddRange(new ToolStripItem[] { toolStripButton4 });
			toolStrip1.Location = new Point(0, 0);
			toolStrip1.Name = "toolStrip1";
			toolStrip1.Size = new Size(497, 27);
			toolStrip1.TabIndex = 0;
			toolStrip1.Text = "toolStrip1";
			// 
			// toolStripButton4
			// 
			toolStripButton4.DisplayStyle = ToolStripItemDisplayStyle.Image;
			toolStripButton4.Image = (Image)resources.GetObject("toolStripButton4.Image");
			toolStripButton4.ImageTransparentColor = Color.Magenta;
			toolStripButton4.Name = "toolStripButton4";
			toolStripButton4.Size = new Size(29, 24);
			toolStripButton4.Text = "toolStripButton4";
			// 
			// splitContainerMovie
			// 
			splitContainerMovie.Dock = DockStyle.Fill;
			splitContainerMovie.Location = new Point(0, 0);
			splitContainerMovie.Margin = new Padding(3, 4, 3, 4);
			splitContainerMovie.Name = "splitContainerMovie";
			splitContainerMovie.Orientation = Orientation.Horizontal;
			// 
			// splitContainerMovie.Panel1
			// 
			splitContainerMovie.Panel1.Controls.Add(tableLayoutPanelMovieTitle);
			// 
			// splitContainerMovie.Panel2
			// 
			splitContainerMovie.Panel2.Controls.Add(tableLayoutPanelMovie);
			splitContainerMovie.Size = new Size(623, 815);
			splitContainerMovie.SplitterDistance = 135;
			splitContainerMovie.SplitterWidth = 5;
			splitContainerMovie.TabIndex = 0;
			// 
			// tableLayoutPanelMovieTitle
			// 
			tableLayoutPanelMovieTitle.ColumnCount = 2;
			tableLayoutPanelMovieTitle.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
			tableLayoutPanelMovieTitle.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70F));
			tableLayoutPanelMovieTitle.Dock = DockStyle.Fill;
			tableLayoutPanelMovieTitle.Location = new Point(0, 0);
			tableLayoutPanelMovieTitle.Margin = new Padding(3, 4, 3, 4);
			tableLayoutPanelMovieTitle.Name = "tableLayoutPanelMovieTitle";
			tableLayoutPanelMovieTitle.RowCount = 1;
			tableLayoutPanelMovieTitle.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
			tableLayoutPanelMovieTitle.Size = new Size(623, 135);
			tableLayoutPanelMovieTitle.TabIndex = 0;
			// 
			// tableLayoutPanelMovie
			// 
			tableLayoutPanelMovie.ColumnCount = 1;
			tableLayoutPanelMovie.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
			tableLayoutPanelMovie.Controls.Add(tableLayoutPanelDetails, 0, 0);
			tableLayoutPanelMovie.Controls.Add(tableLayoutPanelInhalt, 0, 1);
			tableLayoutPanelMovie.Dock = DockStyle.Fill;
			tableLayoutPanelMovie.Location = new Point(0, 0);
			tableLayoutPanelMovie.Margin = new Padding(3, 4, 3, 4);
			tableLayoutPanelMovie.Name = "tableLayoutPanelMovie";
			tableLayoutPanelMovie.RowCount = 2;
			tableLayoutPanelMovie.RowStyles.Add(new RowStyle(SizeType.Absolute, 133F));
			tableLayoutPanelMovie.RowStyles.Add(new RowStyle(SizeType.Absolute, 160F));
			tableLayoutPanelMovie.Size = new Size(623, 675);
			tableLayoutPanelMovie.TabIndex = 4;
			// 
			// tableLayoutPanelDetails
			// 
			tableLayoutPanelDetails.ColumnCount = 4;
			tableLayoutPanelDetails.ColumnStyles.Add(new ColumnStyle());
			tableLayoutPanelDetails.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65F));
			tableLayoutPanelDetails.ColumnStyles.Add(new ColumnStyle());
			tableLayoutPanelDetails.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
			tableLayoutPanelDetails.Controls.Add(label1, 0, 0);
			tableLayoutPanelDetails.Controls.Add(label2, 0, 1);
			tableLayoutPanelDetails.Controls.Add(label4, 2, 0);
			tableLayoutPanelDetails.Controls.Add(textBoxMovieTitle, 1, 0);
			tableLayoutPanelDetails.Controls.Add(textBoxMovieYear, 3, 0);
			tableLayoutPanelDetails.Controls.Add(textBoxMovieTitleOri, 1, 1);
			tableLayoutPanelDetails.Controls.Add(label3, 0, 2);
			tableLayoutPanelDetails.Controls.Add(textBoxMovieDirector, 1, 2);
			tableLayoutPanelDetails.Controls.Add(label5, 2, 1);
			tableLayoutPanelDetails.Controls.Add(dateTimePickerMovieRelease, 3, 1);
			tableLayoutPanelDetails.Controls.Add(label6, 2, 2);
			tableLayoutPanelDetails.Controls.Add(textBoxMovieRating, 3, 2);
			tableLayoutPanelDetails.Dock = DockStyle.Fill;
			tableLayoutPanelDetails.Location = new Point(3, 4);
			tableLayoutPanelDetails.Margin = new Padding(3, 4, 3, 4);
			tableLayoutPanelDetails.Name = "tableLayoutPanelDetails";
			tableLayoutPanelDetails.RowCount = 5;
			tableLayoutPanelDetails.RowStyles.Add(new RowStyle());
			tableLayoutPanelDetails.RowStyles.Add(new RowStyle());
			tableLayoutPanelDetails.RowStyles.Add(new RowStyle());
			tableLayoutPanelDetails.RowStyles.Add(new RowStyle(SizeType.Absolute, 27F));
			tableLayoutPanelDetails.RowStyles.Add(new RowStyle(SizeType.Absolute, 27F));
			tableLayoutPanelDetails.Size = new Size(617, 125);
			tableLayoutPanelDetails.TabIndex = 0;
			// 
			// label1
			// 
			label1.Dock = DockStyle.Fill;
			label1.Location = new Point(3, 0);
			label1.Name = "label1";
			label1.Size = new Size(91, 44);
			label1.TabIndex = 0;
			label1.Text = "Titel:";
			label1.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			label2.Dock = DockStyle.Fill;
			label2.Location = new Point(3, 44);
			label2.Name = "label2";
			label2.Size = new Size(91, 44);
			label2.TabIndex = 1;
			label2.Text = "Original:";
			label2.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label4
			// 
			label4.Dock = DockStyle.Fill;
			label4.Location = new Point(387, 0);
			label4.Name = "label4";
			label4.Size = new Size(72, 44);
			label4.TabIndex = 3;
			label4.Text = "Jahr:";
			label4.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// textBoxMovieTitle
			// 
			textBoxMovieTitle.Dock = DockStyle.Fill;
			textBoxMovieTitle.Location = new Point(100, 4);
			textBoxMovieTitle.Margin = new Padding(3, 4, 3, 4);
			textBoxMovieTitle.Name = "textBoxMovieTitle";
			textBoxMovieTitle.Size = new Size(281, 27);
			textBoxMovieTitle.TabIndex = 4;
			// 
			// textBoxMovieYear
			// 
			textBoxMovieYear.Dock = DockStyle.Fill;
			textBoxMovieYear.Location = new Point(465, 4);
			textBoxMovieYear.Margin = new Padding(3, 4, 3, 4);
			textBoxMovieYear.Name = "textBoxMovieYear";
			textBoxMovieYear.Size = new Size(149, 27);
			textBoxMovieYear.TabIndex = 5;
			// 
			// textBoxMovieTitleOri
			// 
			textBoxMovieTitleOri.Dock = DockStyle.Fill;
			textBoxMovieTitleOri.Location = new Point(100, 48);
			textBoxMovieTitleOri.Margin = new Padding(3, 4, 3, 4);
			textBoxMovieTitleOri.Name = "textBoxMovieTitleOri";
			textBoxMovieTitleOri.Size = new Size(281, 27);
			textBoxMovieTitleOri.TabIndex = 6;
			// 
			// label3
			// 
			label3.Dock = DockStyle.Fill;
			label3.Location = new Point(3, 88);
			label3.Name = "label3";
			label3.Size = new Size(91, 44);
			label3.TabIndex = 2;
			label3.Text = "Regie:";
			label3.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// textBoxMovieDirector
			// 
			textBoxMovieDirector.Dock = DockStyle.Fill;
			textBoxMovieDirector.Location = new Point(100, 92);
			textBoxMovieDirector.Margin = new Padding(3, 4, 3, 4);
			textBoxMovieDirector.Name = "textBoxMovieDirector";
			textBoxMovieDirector.Size = new Size(281, 27);
			textBoxMovieDirector.TabIndex = 7;
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Dock = DockStyle.Fill;
			label5.Location = new Point(387, 44);
			label5.Name = "label5";
			label5.Size = new Size(72, 44);
			label5.TabIndex = 8;
			label5.Text = "Release:";
			label5.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// dateTimePickerMovieRelease
			// 
			dateTimePickerMovieRelease.Format = DateTimePickerFormat.Short;
			dateTimePickerMovieRelease.Location = new Point(465, 48);
			dateTimePickerMovieRelease.Margin = new Padding(3, 4, 3, 4);
			dateTimePickerMovieRelease.Name = "dateTimePickerMovieRelease";
			dateTimePickerMovieRelease.Size = new Size(147, 27);
			dateTimePickerMovieRelease.TabIndex = 9;
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Dock = DockStyle.Fill;
			label6.Location = new Point(387, 88);
			label6.Name = "label6";
			label6.Size = new Size(72, 44);
			label6.TabIndex = 10;
			label6.Text = "Rating:";
			label6.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// textBoxMovieRating
			// 
			textBoxMovieRating.Dock = DockStyle.Fill;
			textBoxMovieRating.Location = new Point(465, 92);
			textBoxMovieRating.Margin = new Padding(3, 4, 3, 4);
			textBoxMovieRating.Name = "textBoxMovieRating";
			textBoxMovieRating.Size = new Size(149, 27);
			textBoxMovieRating.TabIndex = 11;
			// 
			// tableLayoutPanelInhalt
			// 
			tableLayoutPanelInhalt.ColumnCount = 1;
			tableLayoutPanelInhalt.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
			tableLayoutPanelInhalt.Controls.Add(groupBox1, 0, 0);
			tableLayoutPanelInhalt.Controls.Add(groupBox2, 0, 1);
			tableLayoutPanelInhalt.Controls.Add(flowLayoutPanelMoviePictures, 0, 2);
			tableLayoutPanelInhalt.Dock = DockStyle.Fill;
			tableLayoutPanelInhalt.Location = new Point(3, 137);
			tableLayoutPanelInhalt.Margin = new Padding(3, 4, 3, 4);
			tableLayoutPanelInhalt.Name = "tableLayoutPanelInhalt";
			tableLayoutPanelInhalt.RowCount = 3;
			tableLayoutPanelInhalt.RowStyles.Add(new RowStyle(SizeType.Absolute, 107F));
			tableLayoutPanelInhalt.RowStyles.Add(new RowStyle(SizeType.Absolute, 160F));
			tableLayoutPanelInhalt.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
			tableLayoutPanelInhalt.Size = new Size(617, 534);
			tableLayoutPanelInhalt.TabIndex = 1;
			// 
			// groupBox1
			// 
			groupBox1.Controls.Add(textBoxMoviePlot);
			groupBox1.Dock = DockStyle.Fill;
			groupBox1.Location = new Point(3, 4);
			groupBox1.Margin = new Padding(3, 4, 3, 4);
			groupBox1.Name = "groupBox1";
			groupBox1.Padding = new Padding(3, 4, 3, 4);
			groupBox1.Size = new Size(611, 99);
			groupBox1.TabIndex = 0;
			groupBox1.TabStop = false;
			groupBox1.Text = "Plot";
			// 
			// textBoxMoviePlot
			// 
			textBoxMoviePlot.AcceptsReturn = true;
			textBoxMoviePlot.Dock = DockStyle.Fill;
			textBoxMoviePlot.Location = new Point(3, 24);
			textBoxMoviePlot.Margin = new Padding(3, 4, 3, 4);
			textBoxMoviePlot.Multiline = true;
			textBoxMoviePlot.Name = "textBoxMoviePlot";
			textBoxMoviePlot.ScrollBars = ScrollBars.Vertical;
			textBoxMoviePlot.Size = new Size(605, 71);
			textBoxMoviePlot.TabIndex = 0;
			// 
			// groupBox2
			// 
			groupBox2.Controls.Add(textBoxMovieInhalt);
			groupBox2.Dock = DockStyle.Fill;
			groupBox2.Location = new Point(3, 111);
			groupBox2.Margin = new Padding(3, 4, 3, 4);
			groupBox2.Name = "groupBox2";
			groupBox2.Padding = new Padding(3, 4, 3, 4);
			groupBox2.Size = new Size(611, 152);
			groupBox2.TabIndex = 1;
			groupBox2.TabStop = false;
			groupBox2.Text = "Inhalt";
			// 
			// textBoxMovieInhalt
			// 
			textBoxMovieInhalt.AcceptsReturn = true;
			textBoxMovieInhalt.Dock = DockStyle.Fill;
			textBoxMovieInhalt.Location = new Point(3, 24);
			textBoxMovieInhalt.Margin = new Padding(3, 4, 3, 4);
			textBoxMovieInhalt.Multiline = true;
			textBoxMovieInhalt.Name = "textBoxMovieInhalt";
			textBoxMovieInhalt.ScrollBars = ScrollBars.Vertical;
			textBoxMovieInhalt.Size = new Size(605, 124);
			textBoxMovieInhalt.TabIndex = 1;
			// 
			// flowLayoutPanelMoviePictures
			// 
			flowLayoutPanelMoviePictures.AutoScroll = true;
			flowLayoutPanelMoviePictures.AutoSize = true;
			flowLayoutPanelMoviePictures.Dock = DockStyle.Fill;
			flowLayoutPanelMoviePictures.Location = new Point(3, 271);
			flowLayoutPanelMoviePictures.Margin = new Padding(3, 4, 3, 4);
			flowLayoutPanelMoviePictures.Name = "flowLayoutPanelMoviePictures";
			flowLayoutPanelMoviePictures.Size = new Size(611, 259);
			flowLayoutPanelMoviePictures.TabIndex = 2;
			// 
			// statusStripMain
			// 
			statusStripMain.ImageScalingSize = new Size(20, 20);
			statusStripMain.Items.AddRange(new ToolStripItem[] { toolStripProgressBarMain, toolStripStatusLabelMain });
			statusStripMain.Location = new Point(0, 854);
			statusStripMain.Name = "statusStripMain";
			statusStripMain.Padding = new Padding(1, 0, 16, 0);
			statusStripMain.Size = new Size(1125, 27);
			statusStripMain.TabIndex = 0;
			statusStripMain.Text = "statusStrip1";
			// 
			// toolStripProgressBarMain
			// 
			toolStripProgressBarMain.Name = "toolStripProgressBarMain";
			toolStripProgressBarMain.Size = new Size(114, 19);
			// 
			// toolStripStatusLabelMain
			// 
			toolStripStatusLabelMain.Name = "toolStripStatusLabelMain";
			toolStripStatusLabelMain.Size = new Size(51, 21);
			toolStripStatusLabelMain.Text = "Bereit.";
			// 
			// toolStripMain
			// 
			toolStripMain.ImageScalingSize = new Size(32, 32);
			toolStripMain.Items.AddRange(new ToolStripItem[] { toolStripButton1, toolStripButton2, toolStripButton3 });
			toolStripMain.Location = new Point(0, 0);
			toolStripMain.Name = "toolStripMain";
			toolStripMain.Size = new Size(1125, 39);
			toolStripMain.TabIndex = 1;
			toolStripMain.Text = "toolStrip1";
			// 
			// toolStripButton1
			// 
			toolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Image;
			toolStripButton1.Image = (Image)resources.GetObject("toolStripButton1.Image");
			toolStripButton1.ImageTransparentColor = Color.Magenta;
			toolStripButton1.Name = "toolStripButton1";
			toolStripButton1.Size = new Size(36, 36);
			toolStripButton1.Text = "toolStripButton1";
			// 
			// toolStripButton2
			// 
			toolStripButton2.DisplayStyle = ToolStripItemDisplayStyle.Image;
			toolStripButton2.Image = (Image)resources.GetObject("toolStripButton2.Image");
			toolStripButton2.ImageTransparentColor = Color.Magenta;
			toolStripButton2.Name = "toolStripButton2";
			toolStripButton2.Size = new Size(36, 36);
			toolStripButton2.Text = "toolStripButton2";
			// 
			// toolStripButton3
			// 
			toolStripButton3.DisplayStyle = ToolStripItemDisplayStyle.Image;
			toolStripButton3.Image = (Image)resources.GetObject("toolStripButton3.Image");
			toolStripButton3.ImageTransparentColor = Color.Magenta;
			toolStripButton3.Name = "toolStripButton3";
			toolStripButton3.Size = new Size(36, 36);
			toolStripButton3.Text = "toolStripButton3";
			// 
			// FormMain
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1125, 881);
			Controls.Add(splitContainerMain);
			Controls.Add(statusStripMain);
			Controls.Add(toolStripMain);
			Margin = new Padding(3, 4, 3, 4);
			Name = "FormMain";
			StartPosition = FormStartPosition.CenterScreen;
			Text = "Form1";
			Load += FormMain_Load;
			Shown += FormMain_Shown;
			splitContainerMain.Panel1.ResumeLayout(false);
			splitContainerMain.Panel1.PerformLayout();
			splitContainerMain.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)splitContainerMain).EndInit();
			splitContainerMain.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)fluentListViewMovies).EndInit();
			toolStrip1.ResumeLayout(false);
			toolStrip1.PerformLayout();
			splitContainerMovie.Panel1.ResumeLayout(false);
			splitContainerMovie.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)splitContainerMovie).EndInit();
			splitContainerMovie.ResumeLayout(false);
			tableLayoutPanelMovie.ResumeLayout(false);
			tableLayoutPanelDetails.ResumeLayout(false);
			tableLayoutPanelDetails.PerformLayout();
			tableLayoutPanelInhalt.ResumeLayout(false);
			tableLayoutPanelInhalt.PerformLayout();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			statusStripMain.ResumeLayout(false);
			statusStripMain.PerformLayout();
			toolStripMain.ResumeLayout(false);
			toolStripMain.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private SplitContainer splitContainerMain;
		private StatusStrip statusStripMain;
		private ToolStrip toolStripMain;
		private ToolStripButton toolStripButton1;
		private ToolStripButton toolStripButton2;
		private ToolStripButton toolStripButton3;
		private ToolStrip toolStrip1;
		private ToolStripButton toolStripButton4;
		private Fluent.Lists.AdvancedListView fluentListViewMovies;
		private ToolStripProgressBar toolStripProgressBarMain;
		private SplitContainer splitContainerMovie;
		private TableLayoutPanel tableLayoutPanelMovieTitle;
		private TableLayoutPanel tableLayoutPanelDetails;
		private Label label1;
		private Label label2;
		private Label label4;
		private TextBox textBoxMovieTitle;
		private TextBox textBoxMovieYear;
		private TextBox textBoxMovieTitleOri;
		private Label label3;
		private TextBox textBoxMovieDirector;
		private Label label5;
		private DateTimePicker dateTimePickerMovieRelease;
		private Label label6;
		private TextBox textBoxMovieRating;
		private MoviePictureUC pictureBanner;
		private MoviePictureUC pictureClearLogo;
		private TableLayoutPanel tableLayoutPanelMovie;
		private TableLayoutPanel tableLayoutPanelInhalt;
		private GroupBox groupBox1;
		private TextBox textBoxMoviePlot;
		private GroupBox groupBox2;
		private TextBox textBoxMovieInhalt;
		private FlowLayoutPanel flowLayoutPanelMoviePictures;
		private ToolStripStatusLabel toolStripStatusLabelMain;
	}
}
