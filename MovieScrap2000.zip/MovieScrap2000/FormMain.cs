using Fluent;
using System.Diagnostics;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MovieScrap2000
{
	public partial class FormMain : Form
	{
		public MovieManager MovieMan { get; set; }
		public DatabaseManager DBMan { get; set; } = new DatabaseManager();
		public MetadataService MetaService { get; set; }

		private MovieViewModel? _selectedMovieModel = null;
		private CancellationTokenSource? _pictureLoadingCts; // Zum Abbrechen von Ladevorg�ngen
		public MoviePictureUC MoviePictureUCClearLogo { get; set; }
		public MoviePictureUC MoviePictureUCBanner { get; set; }
		public FormMain()
		{
			InitializeComponent();
			MoviePictureUCClearLogo = new MoviePictureUC() { PictureTyp = "ClearLogo", IsWidthAutoAdjusted = false };
			MoviePictureUCClearLogo.Dock = DockStyle.Fill;
			MoviePictureUCBanner = new MoviePictureUC() { PictureTyp = "Banner", IsWidthAutoAdjusted = false };
			MoviePictureUCBanner.Dock = DockStyle.Fill;
			tableLayoutPanelMovieTitle.Controls.Add(MoviePictureUCClearLogo, 0, 0);
			tableLayoutPanelMovieTitle.Controls.Add(MoviePictureUCBanner, 1, 0);

			MetaService = new MetadataService(DBMan);
			MovieMan = new MovieManager(MetaService);
			MovieMan.ProgressReport += MovieMan_ProgressReport;
		}

		private void MovieMan_ProgressReport(object? sender, int percent)
		{
			// Wir pr�fen InvokeRequired auf der MainForm (oder dem StatusStrip-Control), 
			// da ToolStripItem dies nicht direkt unterst�tzt.
			if (this.InvokeRequired)
			{
				// F�hren Sie die Aktualisierung im UI-Thread durch
				this.Invoke(new Action<int>(UpdateProgressBar), percent);
			}
			else
			{
				// Wir sind bereits im UI-Thread
				UpdateProgressBar(percent);
				if (percent == 100)
					UpdateProgressBar(0);
			}
		}

		private void UpdateProgressBar(int percent)
		{
			// Sicherstellen, dass der Wert im g�ltigen Bereich liegt
			percent = Math.Max(0, Math.Min(100, percent));

			// Die Zuweisung des Wertes erfolgt direkt auf dem ToolStripProgressBar-Element
			toolStripProgressBarMain.Value = percent;

			if (percent == 100)
				toolStripProgressBarMain.Value = 0;
			// Optional: Den Fortschritt als Text in einem ToolStripStatusLabel anzeigen
			// statusLabelProgress.Text = $"Scanne: {percent}%"; 
		}

		private async void FormMain_Load(object sender, EventArgs e)
		{
			SetupFluentListView();
		}

		private async void FormMain_Shown(object sender, EventArgs e)
		{
			// Starten Sie die langlaufende asynchrone Initialisierung, 
			// nachdem das Formular bereits sichtbar ist.
			await InitializeAppAsync();
		}

		private async Task InitializeAppAsync()
		{
			fluentListViewMovies.Enabled = false;
			try
			{
				toolStripStatusLabelMain.Text = "Datenbank wird initialisiert...";
				// Datenbank-Initialisierung (Erstellt DB und Tabellen, falls nicht existent)
				await DBMan.InitializeDatabaseAsync();
				
				bool isPopulated = await MetaService.IsCachePopulatedAsync();

				if (isPopulated)
				{
					// 3a. Datenbank ist gef�llt -> Schnelles Laden der Metadaten
					// Annahme: LoadAllMoviesAsync gibt eine Liste von Objekten f�r die Listview zur�ck
					var movies = await MetaService.LoadAllMoviesAsync();
					fluentListViewMovies.SetObjects(movies);
					toolStripStatusLabelMain.Text = "Bereit.";
				}
				else
				{
					// 3b. Datenbank ist leer -> Vollst�ndiger Scan des Dateisystems und Speichern in der DB
					// DAUERT LANGE!
					toolStripStatusLabelMain.Text = "Datenbank ist leer. Scanne Dateisystem...";
					Application.DoEvents();

					// HINWEIS: Wir m�ssen den MovieManager f�r den Scan noch neu instanziieren 
					// und ihm den MetadataService �bergeben.
					MovieMan = new MovieManager(MetaService);
					MovieMan.ProgressReport += MovieMan_ProgressReport;

					// Erzwingen der Ausf�hrung des gesamten Scan-Vorgangs im Hintergrundthread
					await Task.Run(async () =>
					{
						// Dieser Block l�uft nun garantiert in einem Hintergrundthread.
						// Ruft die urspr�ngliche Async-Methode auf, aber im Kontext des Task.Run
						await MovieMan.ScanDirectoryAsync("Z:\\1_42_6_25556\\Movies");
					});

					toolStripStatusLabelMain.Text = "Scan abgeschlossen.";
					// Daten aus der DB neu laden, nachdem sie gespeichert wurden
					var movies = await MetaService.LoadAllMoviesAsync();
					fluentListViewMovies.SetObjects(movies);
				}
			}
			catch (Exception ex)
			{
				Trace.WriteLine(ex.Message);
			}
			finally
			{
				fluentListViewMovies.Enabled = true;
			}
		}
		private void SetupFluentListView()
		{
			// Sicherstellen, dass die Liste leer und korrekt konfiguriert ist
			fluentListViewMovies.View = View.Details;
			fluentListViewMovies.Columns.Clear();
			fluentListViewMovies.FullRowSelect = true; // Wichtig f�r eine bessere Benutzererfahrung

			// --- Spalten-Definitionen ---

			// 1. ANZEIGE-TITEL (Hauptspalte)
			fluentListViewMovies.Columns.Add(new OLVColumn("Filmtitel", nameof(MovieViewModel.Title))
			{
				Width = 250,
			});

			// 2. JAHR
			fluentListViewMovies.Columns.Add(new OLVColumn("Jahr", nameof(MovieViewModel.Year))
			{
				Width = 70,
				TextAlign = HorizontalAlignment.Center
			});


			// 5. Ordnerpfad (wichtig f�r Debugging, kann versteckt werden)
			fluentListViewMovies.Columns.Add(new OLVColumn("Pfad", nameof(MovieViewModel.FolderPath))
			{
				Width = 150,
				IsVisible = false // Versteckt die Spalte standardm��ig
			});
		}

		private async void fluentListViewMovies_SelectionChanged(object sender, EventArgs e)
		{
			_selectedMovieModel = null;
			if (fluentListViewMovies.SelectedObject is MovieViewModel movieInfo)
				_selectedMovieModel = movieInfo;

			await UpdateDetailPanelAsync();
		}

		private async Task UpdateDetailPanelAsync()
		{
			// Klonen _selectedMovieInfo, um Konsistenz w�hrend der asynchronen Operation zu gew�hrleisten
			MovieViewModel? currentMovieInfo = _selectedMovieModel ?? null;

			if (currentMovieInfo == null)
			{
				textBoxMovieDirector.Text = string.Empty;
				textBoxMovieTitle.Text = string.Empty;
				textBoxMovieTitleOri.Text = string.Empty;
				textBoxMovieYear.Text = string.Empty;
				textBoxMoviePlot.Text = string.Empty;
				textBoxMovieInhalt.Text = string.Empty;
				dateTimePickerMovieRelease.Text = string.Empty;
				textBoxMovieRating.Text = string.Empty;
				return;
			}

			// 1. Volle Details asynchron laden
			try
			{
				// Wir �bergeben den MetadataService, um die DB-Abfrage auszul�sen
				await currentMovieInfo.LoadFullDetailsAsync(MetaService);
			}
			catch (Exception ex)
			{
				Trace.WriteLine($"Fehler beim Vollladen der Movie-Details: {ex.Message}");
				return;
			}

			// Sicherheitspr�fung (f�r den Fall, dass die Auswahl gewechselt wurde)
			if (currentMovieInfo.Id != _selectedMovieModel?.Id) return;

			// 2. Detail-Panel mit den geladenen Daten f�llen
			// Die Daten stammen nun aus dem deserialisierten NFO - Objekt(FullMovieNFO)
			var nfo = currentMovieInfo.FullMovieNFO;
			textBoxMovieDirector.Text = nfo?.DisplayDirectors ?? string.Empty;
			textBoxMovieTitle.Text = currentMovieInfo.Title ?? currentMovieInfo.Title;
			textBoxMovieTitleOri.Text = nfo?.OriginalTitle ?? string.Empty;
			textBoxMovieYear.Text = currentMovieInfo.Year ?? string.Empty;
			textBoxMovieInhalt.Text = currentMovieInfo.Plot ?? string.Empty;
			textBoxMoviePlot.Text = nfo?.Outline ?? string.Empty;
			dateTimePickerMovieRelease.Value = nfo?.ReleaseDateTime ?? DateTime.Now;
			textBoxMovieRating.Text = nfo?.RatingString ?? string.Empty;

			// 3. Bild-Cache-Pr�fung und Laden

			// Vorherige Bilder entsorgen
			MoviePictureUCBanner.DisposeCurrentPicture();
			MoviePictureUCClearLogo.DisposeCurrentPicture();
			flowLayoutPanelMoviePictures.Controls.Clear();

			// Abbrechen der vorherigen Bildlade-Operation, falls eine l�uft
			_pictureLoadingCts?.Cancel();
			_pictureLoadingCts?.Dispose(); // Wichtig: alte CTS entsorgen
			_pictureLoadingCts = new CancellationTokenSource();
			CancellationToken cancellationToken = _pictureLoadingCts.Token;
			// 2. Asynchrone Bildsuche starten und warten
			try
			{
				// a) Im ImageCache pr�fen, ob Bilder (als BLOB) vorhanden sind.
				// b) Falls nicht, Bilder von der Festplatte/Web laden.
				// c) Geladene Bilder als BLOBs in die ImageCache-Tabelle speichern.
				// d) Die Bilder als Pfade/Speicher (MemoryStream) f�r das UI zur�ckgeben.
				Trace.WriteLine($"MetaService.GetOrCacheMoviePicturesAsync() MovieID: {currentMovieInfo.Id}, " +
					$"FolderPath: {currentMovieInfo.FolderPath}, VideoFilePath: {currentMovieInfo.VideoFilePath}");
				var picPaths = await MetaService.GetOrCacheMoviePicturesAsync(currentMovieInfo.Id,
					currentMovieInfo.FolderPath,
					currentMovieInfo.VideoFilePath,
						cancellationToken);

				if (currentMovieInfo.Id != _selectedMovieModel?.Id) return;

				// 4. Bilder dem UI hinzuf�gen (wie in Ihrem Originalcode)
				var pictureBanner = GetNewMoviePictureUC(picPaths.FirstOrDefault(x => x.Type == ImageTypes.Banner));
				var pictureClearLogo = GetNewMoviePictureUC(picPaths.FirstOrDefault(x => x.Type == ImageTypes.ClearLogo));
				var picturePoster = GetNewMoviePictureUC(picPaths.FirstOrDefault(x => x.Type == ImageTypes.Poster));
				var pictureFanart = GetNewMoviePictureUC(picPaths.FirstOrDefault(x => x.Type == ImageTypes.Fanart));
				var pictureClearArt = GetNewMoviePictureUC(picPaths.FirstOrDefault(x => x.Type == ImageTypes.ClearArt));
				var pictureLandscape = GetNewMoviePictureUC(picPaths.FirstOrDefault(x => x.Type == ImageTypes.Landscape));
				var pictureDiskArt = GetNewMoviePictureUC(picPaths.FirstOrDefault(x => x.Type == ImageTypes.DiskArt));
				var pictureKeyArt = GetNewMoviePictureUC(picPaths.FirstOrDefault(x => x.Type == ImageTypes.KeyArt));

				if (picturePoster.uc != null)
				{
					flowLayoutPanelMoviePictures.Controls.Add(picturePoster.uc);
					await picturePoster.uc.SetPlaceHolder();
				}
				if (pictureFanart.uc != null) flowLayoutPanelMoviePictures.Controls.Add(pictureFanart.uc);
				if (pictureClearArt.uc != null) flowLayoutPanelMoviePictures.Controls.Add(pictureClearArt.uc);
				if (pictureLandscape.uc != null) flowLayoutPanelMoviePictures.Controls.Add(pictureLandscape.uc);
				if (pictureDiskArt.uc != null) flowLayoutPanelMoviePictures.Controls.Add(pictureDiskArt.uc);
				if (pictureKeyArt.uc != null) flowLayoutPanelMoviePictures.Controls.Add(pictureKeyArt.uc);

				flowLayoutPanelMoviePictures.PerformLayout();
				flowLayoutPanelMoviePictures.Refresh();
				Application.DoEvents();
				await Task.Yield();

				// --- Paralleles Laden aller Bilder starten ---
				// Wir erstellen eine Liste von Tasks, die alle gleichzeitig starten.
				var pictureLoadingTasks = new List<Task>();
				if (pictureBanner.uc != null)
					pictureLoadingTasks.Add(MoviePictureUCBanner.LoadPictureFromBytes(pictureBanner.img!.Data, cancellationToken));
				if (pictureClearLogo.uc != null)
					pictureLoadingTasks.Add(MoviePictureUCClearLogo.LoadPictureFromBytes(pictureClearLogo.img!.Data, cancellationToken));
				if (picturePoster.uc != null)
					pictureLoadingTasks.Add(picturePoster.uc.LoadPictureFromBytes(picturePoster.img!.Data, cancellationToken));
				if (pictureFanart.uc != null)
					pictureLoadingTasks.Add(pictureFanart.uc.LoadPictureFromBytes(pictureFanart.img!.Data, cancellationToken));
				if (pictureLandscape.uc != null)
					pictureLoadingTasks.Add(pictureLandscape.uc.LoadPictureFromBytes(pictureLandscape.img!.Data, cancellationToken));
				if (pictureClearArt.uc != null)
					pictureLoadingTasks.Add(pictureClearArt.uc.LoadPictureFromBytes(pictureClearArt.img!.Data, cancellationToken));
				if (pictureDiskArt.uc != null)
					pictureLoadingTasks.Add(pictureDiskArt.uc.LoadPictureFromBytes(pictureDiskArt.img!.Data, cancellationToken));
				if (pictureKeyArt.uc != null)
					pictureLoadingTasks.Add(pictureKeyArt.uc.LoadPictureFromBytes(pictureKeyArt.img!.Data, cancellationToken));

				// Auf den Abschluss ALLER Ladevorg�nge warten
				// Der UI-Thread ist w�hrenddessen NICHT blockiert.
				try
				{
					await Task.WhenAll(pictureLoadingTasks);
				}
				catch (OperationCanceledException)
				{
					// Dies f�ngt Abbr�che ab, wenn der Benutzer einen neuen Eintrag ausw�hlt, 
					// w�hrend Bilder geladen werden.
					// Das ist das normale, erwartete Verhalten bei Abbruch.
					return;
				}
				catch (Exception ex)
				{
					// Behandeln Sie alle anderen Fehler, die beim Laden aufgetreten sind.
					Trace.WriteLine($"Fehler beim Laden der Bilder f�r '{currentMovieInfo.Title}': {ex.Message}");
				}

			}
			catch (OperationCanceledException)
			{
				// Dies ist normal, wenn der Benutzer einen anderen Film ausgew�hlt hat.
				// Nichts tun, oder optional eine Log-Meldung ausgeben.
				Trace.WriteLine($"Bildladen f�r '{currentMovieInfo.Title}' abgebrochen.");
			}
			catch (Exception ex)
			{
				// Andere Fehler (z.B. Datei nicht gefunden, korruptes Bild)
				Trace.WriteLine($"Fehler beim Laden der Bilder f�r '{currentMovieInfo.Title}': {ex.Message}");
			}
			finally
			{
				flowLayoutPanelMoviePictures.PerformLayout();
			}
		}

		private (MoviePictureUC? uc, ImageCacheItem? img) GetNewMoviePictureUC(ImageCacheItem? item)
		{
			if (item == null)
				return (null, null);

			return (
				uc: new MoviePictureUC() { IsWidthAutoAdjusted = true, PictureTyp = item.Type },
				img: item);
		}

		
	}
}
