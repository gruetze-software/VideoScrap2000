﻿using Microsoft.Data.Sqlite;
using MovieScrap2000;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class MetadataService
{
	private readonly DatabaseManager _dbManager;

	public MetadataService(DatabaseManager dbManager)
	{
		_dbManager = dbManager;
	}

	// Hilfsmethode: Prüft, ob Daten in der Haupttabelle vorhanden sind.
	public async Task<bool> IsCachePopulatedAsync()
	{
		using (var connection = _dbManager.GetConnection())
		{
			var command = connection.CreateCommand();
			command.CommandText = "SELECT COUNT(Id) FROM Movie LIMIT 1;";

			// Da ExecuteScalar den Wert als object zurückgibt, muss es konvertiert werden.
			long count = (long)await command.ExecuteScalarAsync();
			return count > 0;
		}
	}

	// Lade-Logik: Gibt nur die notwendigen Metadaten für die Listview zurück.
	public async Task<List<MovieViewModel>> LoadAllMoviesAsync()
	{
		var movies = new List<MovieViewModel>();

		using (var connection = _dbManager.GetConnection())
		{
			var query = @"
            SELECT
                M.Id, M.Title, M.Year, M.Rating, M.Runtime, M.FolderPath, M.Plot,
                M.VideoFilePath, 
                GROUP_CONCAT(G.Name, ', ') AS GenresString
            FROM
                Movie M
            LEFT JOIN
                MovieGenre MG ON M.Id = MG.MovieId
            LEFT JOIN
                Genre G ON MG.GenreId = G.Id
            GROUP BY
                M.Id, M.Title, M.Year, M.Rating, M.Runtime, M.FolderPath, M.Plot, M.VideoFilePath
            ORDER BY
                M.Title ASC;
        ";

			using (var command = connection.CreateCommand())
			{
				command.CommandText = query;

				using (var reader = await command.ExecuteReaderAsync())
				{
					while (await reader.ReadAsync())
					{
						// Index-Reihenfolge nach der SELECT-Anweisung:
						// 0: Id, 1: Title, 2: Year, 3: Rating, 4: Runtime, 5: FolderPath, 6: Plot, 
						// 7: VideoFilePath, 8: GenresString

						// Erstellen und Befüllen des ViewModels
						movies.Add(new MovieViewModel
						{
							Id = reader.GetInt32(0),
							Title = reader.GetString(1),
							Year = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),

							Rating = reader.IsDBNull(3) ? 0.0f : reader.GetFloat(3),
							// Wir nutzen GetInt32 und konvertieren es in einen String (wie im Original)
							Runtime = reader.IsDBNull(4) ? string.Empty : reader.GetInt32(4).ToString(),

							FolderPath = reader.GetString(5),
							Plot = reader.IsDBNull(6) ? string.Empty : reader.GetString(6),

							// Abrufen des VideoFilePath (Index 7)
							VideoFilePath = reader.IsDBNull(7) ? string.Empty : reader.GetString(7),

							// Der zusammengefügte String der Genres (Index 8)
							GenresString = reader.IsDBNull(8) ? string.Empty : reader.GetString(8)
						});
					}
				}
			}
		}

		return movies;
	}

	// --------------------------------------------------------------------------------
	// Core Logic: Normalisiert und speichert ein einzelnes Movie-Objekt
	// --------------------------------------------------------------------------------
	public async Task SaveMovieAsync(Movie movieNfo, string folderPath, string videoFilePath, bool isPlaceholder)
	{
		using (var connection = _dbManager.GetConnection())
		{
			// Starte eine Transaktion, um alle Inserts entweder vollständig oder gar nicht auszuführen
			using (var transaction = connection.BeginTransaction())
			{
				try
				{
					// 1. Haupttabelle Movie speichern (Upsert) und MovieId abrufen
					int movieId = await UpsertMovieMainAsync(connection, transaction, movieNfo, folderPath, videoFilePath, isPlaceholder);

					// 2. VERBINDUNGSTABELLEN NUR SPEICHERN, WENN KEIN PLATZHALTER
					if (!isPlaceholder)
					{
						// Actor-Normalisierung
						var actorIds = new List<(int id, string? role, int order)>();
						foreach (var actor in movieNfo.Actors)
						{
							int actorId = await UpsertAndGetIdAsync(connection, transaction, "Actor", actor.Name);
							actorIds.Add((actorId, actor.Role, actor.Order));
						}

						// Director-Normalisierung
						var directorIds = new List<(int Id, string? Value, int SortOrder)>();
						foreach (var directorName in movieNfo.Directors)
						{
							int directorId = await UpsertAndGetIdAsync(connection, transaction, "Director", directorName);
							directorIds.Add((directorId, null, 0));
						}

						// Genre-Normalisierung
						var genreIds = new List<(int Id, string? Value, int SortOrder)>();
						if (movieNfo.Genres != null)
						{
							foreach (var genreName in movieNfo.Genres)
							{
								int genreId = await UpsertAndGetIdAsync(connection, transaction, "Genre", genreName);
								genreIds.Add((genreId, null, 0));
							}
						}

						// Studio-Normalisierung
						var studioIds = new List<(int Id, string? Value, int SortOrder)>();
						if (movieNfo.Studios != null)
						{
							foreach (var studioname in movieNfo.Studios)
							{
								int studioId = await UpsertAndGetIdAsync(connection, transaction, "Studio", studioname);
								studioIds.Add((studioId, null, 0));
							}
						}

						// Country-Normalisierung
						var countryids = new List<(int Id, string? Value, int SortOrder)>();
						if (movieNfo.Country != null)
						{
							foreach (var countryname in movieNfo.Country)
							{
								int countryid = await UpsertAndGetIdAsync(connection, transaction, "Country", countryname);
								countryids.Add((countryid, null, 0));
							}
						}

						// Credit-Normalisierung
						var creditids = new List<(int Id, string? Value, int SortOrder)>();
						if (movieNfo.Credits != null)
						{
							foreach (var creditname in movieNfo.Credits)
							{
								int creditid = await UpsertAndGetIdAsync(connection, transaction, "Credit", creditname);
								creditids.Add((creditid, null, 0));
							}
						}


						// 3. Verbindungstabellen speichern

						// Verknüpfung Movie <-> Actors
						await InsertMovieJunctionsAsync(connection, transaction, "MovieActor", "ActorId", movieId, actorIds);

						// Verknüpfung Movie <-> Directors
						await InsertMovieJunctionsAsync(connection, transaction, "MovieDirector", "DirectorId", movieId, directorIds);

						// Verknüpfung Movie <-> Studios
						await InsertMovieJunctionsAsync(connection, transaction, "MovieStudio", "StudioId", movieId, studioIds);

						// Verknüpfung Movie <-> Genre
						await InsertMovieJunctionsAsync(connection, transaction, "MovieGenre", "GenreId", movieId, genreIds);

						// Verknüpfung Movie <-> Countries
						await InsertMovieJunctionsAsync(connection, transaction, "MovieCountry", "CountryId", movieId, countryids);

						// Verknüpfung Movie <-> Credits
						await InsertMovieJunctionsAsync(connection, transaction, "MovieCredit", "CreditId", movieId, creditids);
					}

					// 4. Transaktion abschließen
					transaction.Commit();
				}
				catch (Exception ex)
				{
					// Bei Fehlern die Transaktion zurückrollen, um inkonsistente Daten zu vermeiden
					transaction.Rollback();
					throw new Exception($"Fehler beim Speichern von '{movieNfo.Title}' in der DB. " + Utils.GetExcMsg(ex));
				}
			}
		}
	}

	/// <summary>
	/// Führt einen INSERT OR IGNORE für eine Stammdatentabelle aus und liefert die Id zurück.
	/// </summary>
	private async Task<int> UpsertAndGetIdAsync(SqliteConnection connection, SqliteTransaction transaction,
																							string tableName, string nameValue)
	{
		// Versucht einzufügen, ignoriert bei UNIQUE-Konflikt
		using (var command = connection.CreateCommand())
		{
			command.Transaction = transaction;
			command.CommandText = $"INSERT OR IGNORE INTO {tableName} (Name) VALUES (@Name);";
			command.Parameters.AddWithValue("@Name", nameValue);
			await command.ExecuteNonQueryAsync();
		}

		// Liest die Id des gerade eingefügten oder bereits existierenden Eintrags
		using (var command = connection.CreateCommand())
		{
			command.Transaction = transaction;
			command.CommandText = $"SELECT Id FROM {tableName} WHERE Name = @Name;";
			command.Parameters.AddWithValue("@Name", nameValue);

			// ExecuteScalarAsync gibt die Id als long zurück
			var result = await command.ExecuteScalarAsync();
			return Convert.ToInt32(result);
		}
	}

	// Die Methode, die die komplexe Upsert-Logik für die Haupttabelle implementiert.
	private async Task<int> UpsertMovieMainAsync(
		SqliteConnection connection,
		SqliteTransaction transaction,
		Movie nfo, // Umbenannt zu MovieNFO für Klarheit
		string folderPath,
		string videoFilePath,
		bool isPlaceholder)
	{
		// 1. Vorbereiten der variablen Daten
		string now = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"); // Datum/Zeit für DB

		// JSON muss immer (auch für Platzhalter) versucht werden zu serialisieren, 
		// aber nur für vollwertige Filme gespeichert werden.
		string? nfoJsonSerialized = NfoSerializer.Serialize(nfo);

		// Annahme: Die NFO ist immer movie.nfo oder der Name des Videos. 
		// Hier verwenden wir den allgemeinen Pfad, da der NFO-Pfad nicht übergeben wurde.
		long nfoModifiedTimestamp = new FileInfo(Path.Combine(folderPath, "movie.nfo")).LastWriteTimeUtc.Ticks;

		// IDs
		var imdbUniqueId = nfo.UniqueIds?
				.FirstOrDefault(id => id.Type.Equals("imdb", StringComparison.OrdinalIgnoreCase));
		var tmdbUniqueId = nfo.UniqueIds?
				.FirstOrDefault(id => id.Type.Equals("tmdb", StringComparison.OrdinalIgnoreCase));

		// Status
		int scrapStatus = isPlaceholder ? 1 : 0;

		// Platzhalter-Werte auf NULL oder Standard setzen
		string title = nfo.Title ?? Path.GetFileName(folderPath) ?? "Unbekannter Film"; // Titel ist Pflicht
		string? originalTitle = isPlaceholder ? null : nfo.OriginalTitle;
		string? year = isPlaceholder ? null : nfo.Year; // Jahr auf NULL setzen
		string? plot = isPlaceholder ? nfo.Plot : nfo.Plot; // Plot kann den Platzhaltertext enthalten
		string? outline = isPlaceholder ? null : nfo.Outline;
		string? tagline = isPlaceholder ? null : nfo.Tagline;
		string? mpaa = isPlaceholder ? null : nfo.Mpaa;
		decimal? rating = isPlaceholder ? null : nfo.Rating;
		int? runtime = isPlaceholder ? null : nfo.Runtime;
		string? jsonToSave = isPlaceholder ? null : nfoJsonSerialized;

		// 2. SQL-Befehl (ALLE SPALTEN MÜSSEN HIER UND UNTEN ENTHALTEN SEIN)
		using (var command = connection.CreateCommand())
		{
			command.Transaction = transaction;

			var upsertQuery = $@"
            INSERT INTO Movie (Title, OriginalTitle, Year, FolderPath, VideoFilePath, Plot, Outline, Tagline, Rating, Runtime, Mpaa, ImdbId, TMDbId, JsonMetadata, NfoModified, DateAdded, DateModified, ScrapStatus) 
            VALUES (@Title, @OriginalTitle, @Year, @FolderPath, @VideoFilePath, @Plot, @Outline, @Tagline, @Rating, @Runtime, @Mpaa, @ImdbId, @TMDbId, @JsonMetadata, @NfoModified, @NowAdded, @NowModified, @ScrapStatus)
            ON CONFLICT(FolderPath) DO UPDATE SET
                Title = excluded.Title,
                OriginalTitle = excluded.OriginalTitle,
                Year = excluded.Year,
                VideoFilePath = excluded.VideoFilePath,
                Plot = excluded.Plot,
                Outline = excluded.Outline,
                Tagline = excluded.Tagline,
                Rating = excluded.Rating,
                Runtime = excluded.Runtime,
                Mpaa = excluded.Mpaa,
                ImdbId = excluded.ImdbId,
                TMDbId = excluded.TMDbId,
                JsonMetadata = excluded.JsonMetadata,
                NfoModified = excluded.NfoModified,
                DateModified = excluded.DateModified, -- Aktualisiere nur ModifiedDate

                -- ScrapStatus-Logik
                ScrapStatus = CASE 
                    -- Wenn alter Status PENDING (1) und neuer Status COMPLETE (0) -> Setze auf COMPLETE
                    WHEN Movie.ScrapStatus = 1 AND excluded.ScrapStatus = 0 THEN 0 
                    ELSE excluded.ScrapStatus 
                END;

            SELECT Id FROM Movie WHERE FolderPath = @FolderPath;
        ";

			command.CommandText = upsertQuery;

			// 3. Parameterbindung (mit korrekter Zuweisung der Platzhalter-Werte)

			// IDs
			command.Parameters.AddWithValue("@ImdbId", (object?)imdbUniqueId?.IdValue ?? DBNull.Value);
			// TMDb-ID muss als INTEGER gespeichert werden, falls die Spalte so definiert ist.
			object tmdbIdParam = DBNull.Value;
			if (tmdbUniqueId != null && int.TryParse(tmdbUniqueId.IdValue, out int tmdbId))
			{
				tmdbIdParam = tmdbId;
			}
			command.Parameters.AddWithValue("@TMDbId", tmdbIdParam);

			// String-Felder verwenden die Platzhalter-Variablen
			command.Parameters.AddWithValue("@Title", title);
			command.Parameters.AddWithValue("@OriginalTitle", (object?)originalTitle ?? DBNull.Value);
			command.Parameters.AddWithValue("@Year", (object?)year ?? DBNull.Value);
			command.Parameters.AddWithValue("@Plot", (object?)plot ?? DBNull.Value);
			command.Parameters.AddWithValue("@Outline", (object?)outline ?? DBNull.Value);
			command.Parameters.AddWithValue("@Tagline", (object?)tagline ?? DBNull.Value);
			command.Parameters.AddWithValue("@Mpaa", (object?)mpaa ?? DBNull.Value);

			// Numerische Felder
			command.Parameters.AddWithValue("@Rating", (object?)rating ?? DBNull.Value);
			command.Parameters.AddWithValue("@Runtime", (object?)runtime ?? DBNull.Value);

			// System-Parameter
			command.Parameters.AddWithValue("@FolderPath", folderPath); 
			command.Parameters.AddWithValue("@VideoFilePath", videoFilePath);
			command.Parameters.AddWithValue("@NfoModified", nfoModifiedTimestamp);
			command.Parameters.AddWithValue("@JsonMetadata", (object?)jsonToSave ?? DBNull.Value);
			command.Parameters.AddWithValue("@ScrapStatus", scrapStatus);

			// Zeitstempel
			command.Parameters.AddWithValue("@NowAdded", now);
			command.Parameters.AddWithValue("@NowModified", now);

			// 4. Ausführen und Id abrufen
			var result = await command.ExecuteScalarAsync();

			if (result == null)
			{
				throw new InvalidOperationException($"Konnten MovieId für {nfo.Title} nicht abrufen.");
			}
			return Convert.ToInt32(result);
		}
	}

	/// <summary>
	/// Fügt die Verknüpfungen in die Junction-Tabelle ein.
	/// Dies geschieht in zwei Schritten: Alte Verknüpfungen löschen, neue einfügen.
	/// </summary>
	/// <param name="connection">Die aktuelle SQLite-Verbindung.</param>
	/// <param name="transaction">Die aktive Transaktion.</param>
	/// <param name="junctionTableName">Name der Verknüpfungstabelle (z.B. MovieActor).</param>
	/// <param name="foreignKeyIdName">Name der Fremdschlüssel-Spalte (z.B. ActorId).</param>
	/// <param name="movieId">Die ID des Films, zu dem verknüpft wird.</param>
	/// <param name="relatedIds">Liste der Ids und optionaler Zusatzdaten.</param>
	private async Task InsertMovieJunctionsAsync(
			SqliteConnection connection,
			SqliteTransaction transaction,
			string junctionTableName,
			string foreignKeyIdName,
			int movieId,
			List<(int Id, string? Value, int SortOrder)> relatedIds)
	{
		if (!relatedIds.Any())
			return; // Nichts zu tun

		// 1. Alle vorhandenen Verknüpfungen für diesen Film löschen (für Konsistenz)
		using (var deleteCommand = connection.CreateCommand())
		{
			deleteCommand.Transaction = transaction;
			deleteCommand.CommandText = $"DELETE FROM {junctionTableName} WHERE MovieId = @MovieId;";
			deleteCommand.Parameters.AddWithValue("@MovieId", movieId);
			await deleteCommand.ExecuteNonQueryAsync();
		}

		// 2. Neue Verknüpfungen einfügen (Batch-Insert)
		var insertSql = new StringBuilder($"INSERT INTO {junctionTableName} (MovieId, {foreignKeyIdName}");
		var valueSql = new StringBuilder(" VALUES ");

		// Prüfen, ob Zusatzfelder (Role, SortOrder) benötigt werden
		bool hasRoleOrOrder = relatedIds.Any(r => !string.IsNullOrWhiteSpace(r.Value) || r.SortOrder != 0);

		if (hasRoleOrOrder)
		{
			// MovieActor benötigt die Spalten Role und SortOrder
			insertSql.Append(", Role, SortOrder");
			valueSql.Append("(@MovieId, @Id0, @Role0, @Order0)");
		}
		else
		{
			// MovieGenre/MovieDirector benötigen nur die Ids
			valueSql.Append("(@MovieId, @Id0)");
		}

		insertSql.Append(") ");

		// Füge die Werte für alle Elemente hinzu
		for (int i = 1; i < relatedIds.Count; i++)
		{
			if (hasRoleOrOrder)
			{
				valueSql.Append($", (@MovieId, @Id{i}, @Role{i}, @Order{i})");
			}
			else
			{
				valueSql.Append($", (@MovieId, @Id{i})");
			}
		}

		// Führe den Batch-Befehl aus
		using (var insertCommand = connection.CreateCommand())
		{
			insertCommand.Transaction = transaction;
			insertCommand.CommandText = insertSql.ToString() + valueSql.ToString();

			insertCommand.Parameters.AddWithValue("@MovieId", movieId);

			for (int i = 0; i < relatedIds.Count; i++)
			{
				var item = relatedIds[i];
				// Bindet die Fremdschlüssel-ID (ActorId, GenreId, etc.)
				insertCommand.Parameters.AddWithValue($"@Id{i}", item.Id);

				// Bindet optionale Zusatzdaten
				if (hasRoleOrOrder)
				{
					insertCommand.Parameters.AddWithValue($"@Role{i}", (object?)item.Value ?? DBNull.Value);
					insertCommand.Parameters.AddWithValue($"@Order{i}", item.SortOrder);
				}
			}

			await insertCommand.ExecuteNonQueryAsync();
		}
	}


	// Bestandteil der MetadataService-Klasse
	// Annahme: Sie haben eine Tupel-Definition für die Rückgabe von Details
	public async Task<(Movie Nfo, List<Actor> Actors)> LoadFullMovieDetailsAsync(int movieId)
	{
		using (var connection = _dbManager.GetConnection())
		{
			// 1. JSON-Metadaten laden
			string? json = null;
			using (var command = connection.CreateCommand())
			{
				// Abfrage des JsonMetadata-Strings
				command.CommandText = "SELECT JsonMetadata FROM Movie WHERE Id = @Id";
				command.Parameters.AddWithValue("@Id", movieId);
				var result = await command.ExecuteScalarAsync();
				json = result as string;
			}
			Movie? nfo = NfoSerializer.Deserialize<Movie>(json ?? string.Empty);

			if (nfo == null)
			{
				throw new Exception($"Konnte NFO-Metadaten für MovieId {movieId} nicht deserialisieren.");
			}

			// 2. Actors laden (Muss aus MovieActor Junction-Tabelle geholt werden)
			// HINWEIS: Hier ist eine komplexe JOIN-Abfrage erforderlich, 
			// um Name, Rolle und SortOrder abzurufen.

			var actorQuery = @"
            SELECT A.Name, MA.Role, MA.SortOrder 
            FROM MovieActor MA
            JOIN Actor A ON MA.ActorId = A.Id
            WHERE MA.MovieId = @Id
            ORDER BY MA.SortOrder ASC;
        ";

			var actors = new List<Actor>(); // Annahme der Klasse
			using (var command = connection.CreateCommand())
			{
				command.CommandText = actorQuery;
				command.Parameters.AddWithValue("@Id", movieId);
				using (var reader = await command.ExecuteReaderAsync())
				{
					while (await reader.ReadAsync())
					{
						actors.Add(new Actor
						{
							Name = reader.GetString(0),
							Role = reader.IsDBNull(1) ? null : reader.GetString(1),
							Order = reader.GetInt32(2)
						});
					}
				}
			}

			// ... (Weitere Verknüpfungen wie Directors laden) ...

			return (nfo, actors); // Oder die gesamte Struktur in einem Detail-Objekt zurückgeben
		}
	}

	public async Task<List<ImageCacheItem>> GetOrCacheMoviePicturesAsync(
		int movieId,
		string movieFolderPath,
		string? videoFilePath, // NEU: Benötigt für die Bildsuche
		CancellationToken cancellationToken)
	{
		var cachedImages = new List<ImageCacheItem>();

		// Die Liste aller Bildtypen, die wir erwarten
		var requiredTypes = new List<string> {
				ImageTypes.Poster,
				ImageTypes.Fanart,
				ImageTypes.ClearLogo,
				ImageTypes.Banner,
				ImageTypes.Landscape,
				ImageTypes.ClearArt,
				ImageTypes.KeyArt,
				ImageTypes.DiskArt
		};

		using (var connection = _dbManager.GetConnection())
		{
			// 1. Laden der vorhandenen Cache-Einträge
			// ... (Logik zum Laden der cachedImages bleibt unverändert) ...
			var selectQuery = "SELECT Id, Type, Data FROM ImageCache WHERE MovieId = @MovieId;";

			using (var command = connection.CreateCommand())
			{
				command.CommandText = selectQuery;
				command.Parameters.AddWithValue("@MovieId", movieId);

				using (var reader = await command.ExecuteReaderAsync(cancellationToken))
				{
					while (await reader.ReadAsync())
					{
						cachedImages.Add(new ImageCacheItem
						{
							Id = reader.GetInt32(0),
							Type = reader.GetString(1),
							Data = (byte[])reader.GetValue(2)
						});
					}
				}
			}

			// 2. Prüfen, welche Bilder fehlen
			var missingTypes = requiredTypes
					.Except(cachedImages.Select(c => c.Type), StringComparer.OrdinalIgnoreCase)
					.ToList();

			if (missingTypes.Any())
			{
				// 3. Nachladen, Speichern und Cachen in einer Transaktion
				using (var transaction = connection.BeginTransaction())
				{
					try
					{
						foreach (var type in missingTypes)
						{
							cancellationToken.ThrowIfCancellationRequested();

							// 🛑 Migration der FindLocalPicturePath Logik
							// Die Dateisuche muss in Task.Run erfolgen, da File.Exists blockiert.
							string? fullPath = await Task.Run(() =>
									FindLocalPicturePath(movieFolderPath, videoFilePath, type), cancellationToken);

							if (!string.IsNullOrEmpty(fullPath) && File.Exists(fullPath))
							{
								// Bild von der Festplatte laden
								byte[] imageData = await File.ReadAllBytesAsync(fullPath, cancellationToken);

								// Speichern in die ImageCache-Tabelle
								var insertQuery = "INSERT INTO ImageCache (MovieId, Type, Data) VALUES (@MovieId, @Type, @Data);";

								using (var insertCommand = connection.CreateCommand())
								{
									insertCommand.Transaction = transaction;
									insertCommand.CommandText = insertQuery;
									insertCommand.Parameters.AddWithValue("@MovieId", movieId);
									insertCommand.Parameters.AddWithValue("@Type", type);
									insertCommand.Parameters.AddWithValue("@Data", imageData);

									await insertCommand.ExecuteNonQueryAsync(cancellationToken);
								}

								// Füge das neu geladene Bild zur Rückgabeliste hinzu
								cachedImages.Add(new ImageCacheItem { Type = type, Data = imageData });
							}
						}

						transaction.Commit();
					}
					catch (Exception)
					{
						transaction.Rollback();
						throw;
					}
				}
			}
		}

		return cachedImages;
	}

	private string? FindLocalPicturePath(string folderPath, string? videoFilePath, string picNameEnd)
	{
		if (string.IsNullOrEmpty(folderPath))
			return null;

		// Diese Logik muss synchon ausgeführt werden, da File.Exists keine Async-Version hat.
		// Innerhalb von GetOrCacheMoviePicturesAsync rufen Sie dies in Task.Run auf (wie im Original).

		// 1. Variante: Im Ordner mit Bildtyp-Endung (z.B. D:\Film\poster.png)
		string file = Path.Combine(folderPath, picNameEnd + ".png");

		// 2. Variante: Dateiname + Bildtyp (z.B. D:\Film\video-poster.png)
		if (!string.IsNullOrEmpty(videoFilePath))
		{
			// Wir müssen den Dateinamen ohne Endung abrufen (Utils.GetNameFromFile)
			string baseFileName = Path.GetFileNameWithoutExtension(videoFilePath);
			file = Path.Combine(folderPath, baseFileName + "-" + picNameEnd + ".png");
		}

		if (File.Exists(file))
			return file;

		// 3. Variante: Endung auf .jpg ändern
		// Da wir schon geprüft haben, ob die PNG-Version existiert, ändern wir jetzt auf JPG.
		if (file.LastIndexOf(".") >= 0)
		{
			file = file.Substring(0, file.LastIndexOf(".")) + ".jpg";
		}
		else
		{
			file = file + ".jpg";
		}

		if (File.Exists(file))
			return file;

		return null;
	}
}

// minimale Klasse, die in der Listview angezeigt werden könnte
public class MovieViewModel
{
	// Die DB-Id ist wichtig, um später Details oder Bilder nachzuladen
	public int Id { get; set; }

	// Für die Hauptansicht
	public string Title { get; set; } = string.Empty;
	public string Year { get; set; } = string.Empty;
	public string Runtime { get; set; } = string.Empty;
	public string Plot { get; set; } = string.Empty;
	public float Rating { get; set; }

	// Für die Filterung/Details
	public string FolderPath { get; set; } = string.Empty;

	// Der vollständige Pfad zur Haupt-Videodatei (aus der DB-Spalte VideoFilePath)
	public string VideoFilePath { get; set; } = string.Empty;

	// Nur der Dateiname zur einfachen Anzeige
	public string VideoFileName => Path.GetFileName(VideoFilePath);

	// Die Genres als String, um sie direkt anzeigen zu können
	public string GenresString { get; set; } = string.Empty;

	// Speichert das vollständig deserialisierte NFO-Objekt
	public Movie? FullMovieNFO { get; private set; }

	// Speichert die vollständige Liste der Actor-Objekte (mit Rolle, Order)
	public List<Actor>? Actors { get; private set; } // Annahme: MovieActor ist die Klasse

	// NEU: Gibt an, ob die vollen Details geladen wurden
	public bool IsFullDetailsLoaded { get; private set; } = false;

	// Methode zum Laden der vollen Details (Muss von MetadataService injiziert werden)
	public async Task LoadFullDetailsAsync(MetadataService service)
	{
		if (IsFullDetailsLoaded) return; // Doppeltes Laden verhindern

		// Diese neue Methode im Service lädt JSON und Junctions
		var details = await service.LoadFullMovieDetailsAsync(this.Id);

		this.FullMovieNFO = details.Nfo;
		this.Actors = details.Actors; // Oder wie auch immer die Actors zurückgegeben werden

		IsFullDetailsLoaded = true;
	}
}