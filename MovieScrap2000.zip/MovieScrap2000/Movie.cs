﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace MovieScrap2000
{
	[XmlRoot("movie")]
	public class Movie
	{
		// --- Neue IDs ---
		[XmlElement("id")]
		public string? Id { get; set; } // IMDb ID des Scrapers

		[XmlElement("tmdb")]
		public string? TmdbId { get; set; } // TMDb ID (oft doppelt mit <uniqueid>)

		[XmlElement("tmdbcolid")]
		public string? TmdbCollectionId { get; set; } // ID der Filmsammlung/Reihe

		// Die Liste von <uniqueid> Objekten (bleibt unverändert)
		[XmlElement("uniqueid")]
		public List<UniqueId> UniqueIds { get; set; } = new List<UniqueId>();

		// --- Allgemeine Metadaten ---
		[XmlElement("title")]
		public string? Title { get; set; }

		[XmlElement("originaltitle")]
		public string? OriginalTitle { get; set; }

		[XmlElement("language")]
		public string? Language { get; set; }

		[XmlElement("year")]
		public string? Year { get; set; }

		[XmlElement("releasedate")]
		public string? ReleaseDate { get; set; } // YYYY-MM-DD
		[XmlIgnore]
		[JsonIgnore]
		public DateTime? ReleaseDateTime 
		{
			get
			{
				if (DateTime.TryParse(ReleaseDate, out DateTime dt))
					return dt;

				return null;
			}
		}

		[XmlElement("country")]
		public List<string> Country { get; set; } = new List<string>();

		[XmlElement("rating")]
		// Ändern Sie dies zu string
		public string? RatingString { get; set; }
		// ...

		// Fügen Sie eine Hilfseigenschaft hinzu, um den Wert sicher zu konvertieren
		[XmlIgnore]
		[JsonIgnore]
		public decimal Rating
		{
			get
			{
				if (decimal.TryParse(RatingString?.Replace(',', '.'),
														System.Globalization.NumberStyles.Any,
														System.Globalization.CultureInfo.InvariantCulture,
														out decimal value))
				{
					return value;
				}
				return 0m;
			}
		}

		[XmlElement("votes")]
		public int Votes { get; set; }

		[XmlElement("mpaa")]
		public string? Mpaa { get; set; }

		[XmlElement("genre")]
		public List<string> Genres { get; set; } = new List<string>();
		
		[XmlIgnore]
		[JsonIgnore]
		public string? DisplayGenres
		{
			get
			{
				if (Genres.Any())
					return string.Join("; ", Genres);
				return null; 
			}
		}

		[XmlElement("studio")]
		public List<string> Studios { get; set; } = new List<string>();
		
		[XmlIgnore]
		[JsonIgnore]
		public string? DisplayStudios
		{
			get
			{
				if (Studios.Any())
					return string.Join("; ", Studios);
				return null;
			}
		}

		[XmlElement("director")]
		public List<string> Directors { get; set; } = new List<string>();
		
		[XmlIgnore]
		[JsonIgnore]
		public string? DisplayDirectors
		{
			get
			{
				if (Directors.Any())
					return string.Join("; ", Directors);
				return null;
			}
		}

		[XmlElement("credits")]
		public List<string> Credits { get; set; } = new List<string>();

		[XmlElement("outline")]
		public string? Outline { get; set; } // Kurze Zusammenfassung
		
		[XmlElement("tagline")]
		public string? Tagline { get; set; } // Claim/Slogan

		[XmlElement("plot")]
		public string? Plot { get; set; } // Ausführliche Zusammenfassung

		[XmlElement("runtime")]
		public int Runtime { get; set; }

		[XmlElement("dateadded")]
		public string? DateAdded { get; set; } // Datum, wann Film hinzugefügt wurde

		[XmlElement("datemodified")]
		public string? DateModified { get; set; } // Datum der letzten Bearbeitung

		// Die Liste von <actor> Objekten (bleibt unverändert)
		[XmlElement("actor")]
		public List<Actor> Actors { get; set; } = new List<Actor>();

		// Filmreihe/Set-Name
		[XmlElement("set")]
		public string? MovieSet { get; set; }

		// Die komplexe Struktur der Dateiinformationen
		[XmlElement("fileinfo")]
		public MovieFileInfo? FileInfo { get; set; }

		// Sperr-Flag
		[XmlElement("locked")]
		public bool Locked { get; set; }
		
		public Movie()
		{
			
		}

		public override string ToString()
		{
			return $"{Title} ({Year})";
		}
	}
}
