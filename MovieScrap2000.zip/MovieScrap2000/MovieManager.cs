﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MovieScrap2000
{
	public class MovieManager
	{
		private readonly MetadataService _metadataService;

		// --- Events ---
		public event EventHandler<LogMessageObject>? LogMessage;
		public event EventHandler<int>? ProgressReport;

		public MovieManager(MetadataService metadataService)
		{
			_metadataService = metadataService;
		}

		// --- Konstanten ---
		public static readonly HashSet<string> VideoExtensions = new HashSet<string>
		{
				".mp4",
				".mkv",
				".mpg",
				".avi",
				".mov",
				".wmv",
				".flv",
				".ts",
				".webm"
		};

		// --- Veraltete MovieFolderInfo-Felder entfernt ---
		// private List<MovieFolderInfo> _movieList...
		// public IReadOnlyList<MovieFolderInfo> Movies...

		public string? RootPath { get; private set; }

		private void OnLogMessage(string message, LogLevel level = LogLevel.Info, string source = "Scanner")
		{
			LogMessageObject logEntry = new LogMessageObject(message, level, source);
			Trace.WriteLine(logEntry);
			LogMessage?.Invoke(this, logEntry);
		}

		private void OnProgressReport(int percent)
		{
			ProgressReport?.Invoke(this, percent);
		}

		// --- Haupt-Scan-Methode ---

		/// <summary>
		/// Scannt das übergeordnete Verzeichnis, analysiert Ordner parallel und speichert Metadaten sofort in die DB.
		/// </summary>
		/// <param name="rootPath">Der Pfad zum Haupt-Filmordner.</param>
		public async Task ScanDirectoryAsync(string rootPath)
		{
			OnLogMessage($"Starte parallelen Scan des Verzeichnisses: {rootPath}", LogLevel.Info, "Scanner");

			if (!Directory.Exists(rootPath))
			{
				OnLogMessage($"FEHLER: Das Verzeichnis '{rootPath}' existiert nicht.", LogLevel.Error, "Scanner");
				return;
			}

			this.RootPath = rootPath;

			string[] movieFolders = Directory.GetDirectories(rootPath);
			int totalFolders = movieFolders.Length;
			int completedCount = 0;

			OnLogMessage($"-> {totalFolders} Unterordner gefunden. Starte Parallelverarbeitung und DB-Speicherung...", LogLevel.Info, "Scanner");

			// Liste der Tasks für Analyse und Speicherung
			var analysisTasks = movieFolders.Select(folderPath =>
			{
				// 🛑 Wrapper-Funktion, die den Task startet UND den Zähler verwaltet
				return AnalyzeAndSaveMovieFolderAsync(folderPath)
						.ContinueWith(_ =>
						{
							// Dieser Teil wird ausgeführt, NACHDEM AnalyzeAndSaveMovieFolderAsync (inkl. await) abgeschlossen ist
							// (egal ob erfolgreich oder mit Fehler).

							// --- Fortschritts-Tracking (Wie ursprünglich in Parallel.ForEach) ---

							int currentCompleted = Interlocked.Increment(ref completedCount);
							int percent = (int)((double)currentCompleted / totalFolders * 100);

							// Wir verwenden eine einfache Logik, da wir uns jetzt in einem ContinueWith-Thread befinden.
							// ACHTUNG: ProgressReport muss ggf. auf dem UI-Thread ausgeführt werden!
							// Wenn ProgressReport ein Control/Window berührt, müssen Sie Dispatcher/SynchronizationContext verwenden.
							OnProgressReport(percent);

						}, TaskScheduler.Default); // Führen Sie ContinueWith im ThreadPool aus

			}).ToList();

			// Warten auf den Abschluss ALLER Analyse- und Speicheraufgaben
			try
			{
				await Task.WhenAll(analysisTasks);
			}
			catch (Exception ex)
			{
				OnLogMessage($"Fehler während des Parallel-Scans: {ex.Message}", LogLevel.Critical, "Scanner");
			}

			// Am Ende den Status auf 100% setzen
			OnProgressReport(100);

			OnLogMessage($"Scan und Datenbank-Speicherung abgeschlossen.", LogLevel.Info, "Scanner");
		}

		// --- Analyse und Speichern eines einzelnen Ordners (Asynchron) ---

		/// <summary>
		/// Analysiert einen einzelnen Ordner, liest NFO/Video-Pfade und speichert Metadaten/Platzhalter in die DB.
		/// </summary>
		private async Task AnalyzeAndSaveMovieFolderAsync(string folderPath)
		{
			// Lokale Variablen
			string? movieTitleFromFolder = Path.GetFileName(folderPath);
			string? videoFilePath = null;
			string status;
			bool isNfoFound = false;
			Movie? movieNfo = null; 

			try
			{
				// --- Logik für Dateisuche (Video und NFO) ---

				FileInfo[] filesInFolder = new DirectoryInfo(folderPath).GetFiles();

				// 1. Hauptfilm-Datei identifizieren (größte Videodatei)
				var videoFiles = filesInFolder
								.Where(f => VideoExtensions.Contains(f.Extension.ToLower()))
								.ToList();

				if (videoFiles.Any())
				{
					FileInfo mainVideoFile = videoFiles.OrderByDescending(f => f.Length).First();
					videoFilePath = mainVideoFile.FullName;
					OnLogMessage($"Videodatei '{mainVideoFile.Name}' im Ordner '{movieTitleFromFolder}' gefunden.", LogLevel.Info, "Scanner");

				}
				else
				{
					status = "Keine Videodatei gefunden";
					OnLogMessage($"WARNUNG: Keine Videodatei im Ordner '{movieTitleFromFolder}' gefunden.", LogLevel.Warning, "Scanner");
					return;
				}

				// 2. NFO-Datei identifizieren UND LESEN
				string expectedNfoFileName = Path.GetFileNameWithoutExtension(videoFilePath) + ".nfo";
				string expectedNfoPath = Path.Combine(folderPath, expectedNfoFileName);
				FileInfo? nfoFile = null;

				if (File.Exists(expectedNfoPath))
				{
					nfoFile = new FileInfo(expectedNfoPath);
				}
				else
				{
					nfoFile = filesInFolder
									.FirstOrDefault(f => f.Extension.Equals(".nfo", StringComparison.OrdinalIgnoreCase));
				}


				if (nfoFile != null)
				{
					OnLogMessage($"Lese Nfo-Datei '{nfoFile.Name}' im Ordner '{movieTitleFromFolder}'.", LogLevel.Info, "Scanner");
					movieNfo = ReadNfo(nfoFile.FullName);

					if (movieNfo != null)
					{
						status = "NFO vorhanden (gelesen)";
						isNfoFound = true;
					}
					else
					{
						status = "NFO vorhanden (FEHLER beim Lesen)";
						OnLogMessage($"FEHLER beim Lesen der NFO '{nfoFile.FullName}'.", LogLevel.Error, "Scanner");
					}
				}

				// 🛑 3. Platzhalter erstellen, wenn KEIN gültiges NFO-Objekt existiert
				if (movieNfo == null)
				{
					status = "Platzhalter (Scraping nötig)";
					OnLogMessage($"Erzeuge neue Nfo-Datei im Ordner '{movieTitleFromFolder}'.", LogLevel.Info, "Scanner");

					// Minimales NFO-Objekt für den Platzhalter erstellen
					movieNfo = new Movie
					{
						Title = Path.GetFileNameWithoutExtension(videoFilePath) ?? "Unbekannter Film",
						Plot = "Metadaten müssen noch durch Scraping geladen werden.",
						Year = null // Verwenden Sie null oder "0000" (abhängig von der DB-Definition)
					};
				}

				// 🛑 4. Speichere die Daten in der DB (via MetadataService)
				if (movieNfo != null && videoFilePath != null)
				{
					bool isPlaceholder = !isNfoFound;

					OnLogMessage($"Speichere in Datenbank: '{movieTitleFromFolder}'.", LogLevel.Info, "Scanner");

					await _metadataService.SaveMovieAsync(
									movieNfo,
									folderPath,
									videoFilePath,
									isPlaceholder: isPlaceholder);

					status = isPlaceholder ? "Platzhalter gespeichert" : "Metadaten gespeichert";
				}
			}
			catch (Exception ex)
			{
				status = $"KRITISCHER Fehler beim Scannen";
				OnLogMessage($"KRITISCHER Fehler in {movieTitleFromFolder} ({folderPath}): {ex.Message}", LogLevel.Critical, "Scanner");
			}
			finally
			{
				
			}
		}


		// --- NFO-Leselogik ---

		/// <summary>
		/// Liest eine Kodi-kompatible NFO-Datei ein und deserialisiert sie in ein MovieNFO-Objekt.
		/// </summary>
		public Movie? ReadNfo(string nfoFilePath) 
		{
			if (!File.Exists(nfoFilePath))
			{
				return null;
			}

			try
			{
				// Typ auf MovieNFO angepasst (angenommen)
				XmlSerializer serializer = new XmlSerializer(typeof(Movie));

				using (TextReader reader = new StreamReader(nfoFilePath))
				{
					object? deserializedObject = serializer.Deserialize(reader);
					if (deserializedObject is Movie movieData) 
					{
						return movieData;
					}
					else
					{
						return null;
					}
				}
			}
			catch (InvalidOperationException ex)
			{
				Trace.WriteLine($"Fehler beim Deserialisieren der NFO-Datei {nfoFilePath}: {ex.Message}");
				return null;
			}
			catch (Exception ex)
			{
				Trace.WriteLine($"Ein Lesefehler ist aufgetreten: {ex.Message}");
				return null;
			}
		}
	}
}
