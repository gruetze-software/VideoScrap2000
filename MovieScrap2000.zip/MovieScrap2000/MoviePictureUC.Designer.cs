﻿namespace MovieScrap2000
{
	partial class MoviePictureUC
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			groupBoxPicture = new GroupBox();
			tableLayoutPanelPicture = new TableLayoutPanel();
			pictureBoxImage = new PictureBox();
			contextMenuStripUC = new ContextMenuStrip(components);
			viewToolStripMenuItem = new ToolStripMenuItem();
			newToolStripMenuItem = new ToolStripMenuItem();
			deleteToolStripMenuItem = new ToolStripMenuItem();
			groupBoxPicture.SuspendLayout();
			tableLayoutPanelPicture.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBoxImage).BeginInit();
			contextMenuStripUC.SuspendLayout();
			SuspendLayout();
			// 
			// groupBoxPicture
			// 
			groupBoxPicture.Controls.Add(tableLayoutPanelPicture);
			groupBoxPicture.Dock = DockStyle.Fill;
			groupBoxPicture.Location = new Point(0, 0);
			groupBoxPicture.Name = "groupBoxPicture";
			groupBoxPicture.Size = new Size(200, 230);
			groupBoxPicture.TabIndex = 0;
			groupBoxPicture.TabStop = false;
			groupBoxPicture.Text = "PictureType";
			// 
			// tableLayoutPanelPicture
			// 
			tableLayoutPanelPicture.ColumnCount = 1;
			tableLayoutPanelPicture.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
			tableLayoutPanelPicture.Controls.Add(pictureBoxImage, 0, 0);
			tableLayoutPanelPicture.Dock = DockStyle.Fill;
			tableLayoutPanelPicture.Location = new Point(3, 19);
			tableLayoutPanelPicture.Name = "tableLayoutPanelPicture";
			tableLayoutPanelPicture.RowCount = 1;
			tableLayoutPanelPicture.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
			tableLayoutPanelPicture.Size = new Size(194, 208);
			tableLayoutPanelPicture.TabIndex = 0;
			// 
			// pictureBoxImage
			// 
			pictureBoxImage.ContextMenuStrip = contextMenuStripUC;
			pictureBoxImage.Dock = DockStyle.Fill;
			pictureBoxImage.Location = new Point(3, 3);
			pictureBoxImage.Name = "pictureBoxImage";
			pictureBoxImage.Size = new Size(188, 202);
			pictureBoxImage.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBoxImage.TabIndex = 1;
			pictureBoxImage.TabStop = false;
			pictureBoxImage.MouseDoubleClick += pictureBoxImage_MouseDoubleClick;
			// 
			// contextMenuStripUC
			// 
			contextMenuStripUC.Items.AddRange(new ToolStripItem[] { viewToolStripMenuItem, newToolStripMenuItem, deleteToolStripMenuItem });
			contextMenuStripUC.Name = "contextMenuStripUC";
			contextMenuStripUC.Size = new Size(109, 70);
			// 
			// viewToolStripMenuItem
			// 
			viewToolStripMenuItem.Name = "viewToolStripMenuItem";
			viewToolStripMenuItem.Size = new Size(108, 22);
			viewToolStripMenuItem.Text = "View...";
			viewToolStripMenuItem.Click += viewToolStripMenuItem_Click;
			// 
			// newToolStripMenuItem
			// 
			newToolStripMenuItem.Name = "newToolStripMenuItem";
			newToolStripMenuItem.Size = new Size(108, 22);
			newToolStripMenuItem.Text = "New...";
			newToolStripMenuItem.Click += newToolStripMenuItem_Click;
			// 
			// deleteToolStripMenuItem
			// 
			deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
			deleteToolStripMenuItem.Size = new Size(108, 22);
			deleteToolStripMenuItem.Text = "Delete";
			deleteToolStripMenuItem.Click += deleteToolStripMenuItem_Click;
			// 
			// MoviePictureUC
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			Controls.Add(groupBoxPicture);
			Name = "MoviePictureUC";
			Size = new Size(200, 230);
			groupBoxPicture.ResumeLayout(false);
			tableLayoutPanelPicture.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBoxImage).EndInit();
			contextMenuStripUC.ResumeLayout(false);
			ResumeLayout(false);
		}

		#endregion

		private GroupBox groupBoxPicture;
		private TableLayoutPanel tableLayoutPanelPicture;
		private PictureBox pictureBoxImage;
		private ContextMenuStrip contextMenuStripUC;
		private ToolStripMenuItem viewToolStripMenuItem;
		private ToolStripMenuItem newToolStripMenuItem;
		private ToolStripMenuItem deleteToolStripMenuItem;
	}
}
