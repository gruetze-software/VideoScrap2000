﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieScrap2000
{
	public partial class MoviePictureUC : UserControl
	{
		// CancellationTokenSource, um vorherige Ladevorgänge abzubrechen
		private CancellationTokenSource? _loadingCts;

		// Platzhalterbild (MUSS im Konstruktor geladen werden!)
		private Image? _loadingPlaceholder;

		private string? _picType = "Picture";
		public string? PictureTyp { get { return _picType; } set { _picType = value; groupBoxPicture.Text = _picType; } }
		public string? ImagePath { get; set; }
		/// <summary>
		/// Steuert, ob die Breite des UserControls automatisch proportional zur Höhe des geladenen Bildes gesetzt wird.
		/// </summary>
		public bool IsWidthAutoAdjusted { get; set; } = false;

		public MoviePictureUC()
		{
			InitializeComponent();

			// Laden Sie hier Ihr Platzhalterbild (z.B. ein 'Loading'-Icon).
			// Dies muss nur einmal erfolgen. Verwenden Sie einen Pfad zu Ihrer Ressource.
			// Beispiel: Laden aus Ressourcen oder einem festen Pfad
			try
			{
				// Laden Sie ein geeignetes Platzhalterbild (z.B. ein GIF oder PNG mit einem Ladesymbol)
				// HINWEIS: Hier den korrekten Pfad zu Ihrer Laderessource einfügen!
				_loadingPlaceholder = Image.FromFile(Path.Combine(Application.StartupPath, "Resources\\loading.gif"));
			}
			catch { /* Optional: Fehler bei fehlender Lade-Grafik ignorieren */ }
		}

		public async Task SetPlaceHolder()
		{
			DisposeCurrentPicture();
			pictureBoxImage.Image = _loadingPlaceholder;
			pictureBoxImage.Refresh();
			await Task.Yield();
		}

		public async Task LoadPictureFromBytes(byte[] imageData, CancellationToken externalToken)
		{
			// --- Phase 1: Vorbereitung und Abbruch ---

			// Wir nutzen das externe Token und das implizite Abbruch-Handling
			// durch OperationCanceledException, wenn der Benutzer einen neuen Film auswählt.

			// 1. Wenn die Daten leer sind, alles leeren und beenden
			if (imageData == null || imageData.Length == 0)
			{
				DisposeCurrentPicture();
				// ImagePath (string) kann hier nicht gesetzt werden, da es keine Pfadangabe gibt.
				return;
			}

			// 2. Platzhalter anzeigen und Aufräumen des alten Bildes
			// Da wir das externe Token verwenden, müssen wir hier nicht das interne _loadingCts verwalten.
			DisposeCurrentPicture();
			pictureBoxImage.Image = _loadingPlaceholder;
			await Task.Yield();
			pictureBoxImage.Refresh();

			// (Optionaler Guard: Hier könnte man die Hash-ID der Bytes speichern, wenn man wirklich
			// ein Stale-Data-Guard benötigt, aber CancellationToken ist die Hauptlösung.)

			// --- Phase 2: Asynchrones Laden ---
			try
			{
				// Laden des Bildes in einem Hintergrund-Task
				Image loadedImage = await Task.Run(() =>
				{
					// Sicherstellen, dass die Operation abgebrochen werden kann
					externalToken.ThrowIfCancellationRequested();

					// Verwenden des MemoryStreams anstelle von FileStream
					using (var stream = new MemoryStream(imageData))
					{
						// Rückgabe einer Kopie des Bildes, um den Stream sofort schließen zu können
						// .Clone() ist wichtig, da FromStream das Image-Objekt an den Stream koppeln kann.
						return (Image)Image.FromStream(stream).Clone();
					}
				}, externalToken); // Übergeben Sie das Token an Task.Run

				// --- Phase 3: Abschluss und Zuweisung ---

				// Prüfen, ob in der Zwischenzeit ein Abbruch angefordert wurde
				externalToken.ThrowIfCancellationRequested();

				// Altes Platzhalter- oder Bild entsorgen, bevor das neue zugewiesen wird
				DisposeCurrentPicture();
				pictureBoxImage.Image = loadedImage;

				if (IsWidthAutoAdjusted)
				{
					// Führt die proportionale Breitenberechnung durch
					CalculateAndApplyNewSize();
				}
			}
			catch (OperationCanceledException)
			{
				// Dies ist der erwartete Pfad bei Abbruch (z.B. Benutzer wählt neuen Film).
				// Das UserControl bleibt im Ladezustand oder wird geleert (je nach Logik in DisposeCurrentPicture).
			}
			catch (Exception ex)
			{
				// Fehlerbehandlung (z.B. beschädigtes Bild)
				Trace.WriteLine($"Fehler beim Laden des Bildes aus Bytes: {ex.Message}");
				DisposeCurrentPicture();
				// Optional: Hier Platzhalter für Fehlerbild anzeigen
			}
		}

		public void CalculateAndApplyNewSize()
		{
			if ( this.pictureBoxImage.Image == null)
				return;

			// Die feste Höhe des UserControls (z.B. 240px)
			int fixedHeight = this.Height;

			// Berechne den Skalierungsfaktor
			double scaleFactor = (double)fixedHeight / this.pictureBoxImage.Image.Height;

			// Berechne die neue Breite
			int newWidth = (int)(this.pictureBoxImage.Image.Width * scaleFactor);

			// 1. Zuweisung der Breite (die Breite des UserControls wird angepasst)
			this.Width = newWidth + 4; // 12px Puffer für Ränder
		}

		public void DisposeCurrentPicture()
		{
			// Nur das Bild entsorgen, wenn es KEIN Platzhalter ist (den Platzhalter wiederverwenden)
			if (pictureBoxImage.Image != null && pictureBoxImage.Image != _loadingPlaceholder)
			{
				pictureBoxImage.Image.Dispose();
			}
			pictureBoxImage.Image = null;
		}

		private void viewToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(ImagePath))
				Utils.OpenFileWithDefaultApp(ImagePath);
		}

		private void newToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void pictureBoxImage_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			if (!string.IsNullOrEmpty(ImagePath))
				Utils.OpenFileWithDefaultApp(ImagePath);
		}
	}
}
