﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieScrap2000
{
	public static class Utils
	{

		public static string GetTempPath()
		{
			return Path.Combine(Path.GetTempPath(), "MovieScrap2000", "scrape_media");
		}

		public static string GetOptionsPath()
		{
			var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			var dir = Path.Combine(appData, "MovieScrap2000");
			Directory.CreateDirectory(dir); // sicherstellen, dass Ordner existiert
			return dir;
		}

		public static string GetNameFromFile(string? filePath)
		{
			// Liefert den Dateinamen OHNE Erweiterung zurück.
			// Path.GetFileNameWithoutExtension() kann das auch, aber bei
			// Namen wie "Dr. Mario.zip" liefert es nur "Dr." zurück.
			// Daher hier eine eigene Implementierung.

			if (string.IsNullOrWhiteSpace(filePath))
				return string.Empty;

			string filename = Path.GetFileName(filePath);
			int index = filename.LastIndexOf('.');
			if (index < 0)
				return filename.Trim(); // keine Erweiterung
			if (index == 0)
				return string.Empty; // nur Erweiterung, kein Name

			return filename.Substring(0, index).Trim(); // Name ohne Erweiterung
		}

		public static string GetExcMsg(Exception ex)
		{
			string msg = ex.Message;
			if (ex.InnerException != null && ex.InnerException.Message != msg)
				msg += "\r\n" + GetExcMsg(ex.InnerException);
			return msg;
		}

		public static void OpenFileWithDefaultApp(string absPathFile)
		{
			if (!string.IsNullOrEmpty(absPathFile) && File.Exists(absPathFile))
			{
				try
				{
					var psi = new System.Diagnostics.ProcessStartInfo
					{
						FileName = absPathFile,
						UseShellExecute = true // wichtig: Standard-App verwenden
					};
					System.Diagnostics.Process.Start(psi);
				}
				catch (Exception ex)
				{
					MessageBox.Show(Utils.GetExcMsg(ex), "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}
	}
}
